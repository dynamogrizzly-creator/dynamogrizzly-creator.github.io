---
layout: page
title: "Allenamenti Dodgeball Ravenna"
description: "Orari e sedi degli allenamenti dei Ravenna Grizzlies. Adulti, femminile e giovanile. Palestre a Ravenna e Marina di Ravenna. Primo allenamento gratuito."
keywords: "allenamenti dodgeball Ravenna, orari dodgeball Ravenna, palestra dodgeball Ravenna, dove allenarsi Ravenna"
tag: "Orari e sedi"
og_image: "/assets/images/dodgeball-ravenna-grizzlies-hero.webp"
permalink: /allenamenti/
---

Tre squadre, tre programmi. Che tu voglia agonismo o semplicemente divertirti, trovi il gruppo giusto per te. Il primo allenamento è sempre **gratuito e senza impegno**.

---

## Adulti

**Martedì e Giovedì · 21:00 – 23:00**

[📍 Palestra Randi · Via G. Marconi 11, Ravenna](https://maps.google.com/?q=Via+G.+Marconi+11,+Ravenna)

Allenamenti aperti a tutti dai 16 anni in su, qualsiasi livello. Si lavora su tecnica, tattica e gioco libero. L'ambiente è sereno ma agonistico — chi vuole crescere trova stimoli, chi vuole solo divertirsi trova anche quelli.

---

## Giovanile — U13, U15, U18

**Lunedì · 18:00 – 19:30**
[📍 Palestra Liceo Classico Succursale · Via Nino Bixio 29, Ravenna](https://maps.google.com/?q=Via+Nino+Bixio+29,+Ravenna)

**Giovedì · 17:30 – 19:00**
[📍 Palestra Novello 1° piano · Via A. De Gasperi 4, Ravenna](https://maps.google.com/?q=Via+A.+De+Gasperi+4,+Ravenna)

Il settore giovanile è aperto a ragazzi e ragazze nelle categorie U13, U15 e U18. Gli allenatori seguono ogni atleta nella crescita tecnica e sportiva.

---

## Femminile

**Martedì · 17:00 – 18:30**

[📍 Palestra Mattei · Marina di Ravenna](https://maps.google.com/?q=Palestra+Mattei,+Marina+di+Ravenna)

La squadra femminile compete in **Serie A Femminile** con campionesse europee tra le atlete. Gli allenamenti sono aperti a nuove giocatrici di qualsiasi livello.

---

## Come iniziare

Contattaci prima di venire — ti diciamo tutto quello che ti serve sapere e ti aspettiamo in palestra.

<div class="contact-grid" style="margin-top: 2rem;">
  <div class="contact-item">
    <span class="contact-icon">📧</span>
    <span class="contact-label">Email</span>
    <div class="contact-value">
      <a href="mailto:dynamo.grizzly@gmail.com">dynamo.grizzly@gmail.com</a>
    </div>
  </div>
  <div class="contact-item">
    <span class="contact-icon">📱</span>
    <span class="contact-label">WhatsApp / Telefono</span>
    <div class="contact-value">
      <a href="tel:+393289472121">328 947 2121</a>
    </div>
  </div>
</div>

---

Non sai ancora cos'è il Dodgeball? [Scoprilo qui →]({{ site.baseurl }}/dodgeball/)
Vuoi sapere come iscriverti? [Tutte le info →]({{ site.baseurl }}/unisciti/)
