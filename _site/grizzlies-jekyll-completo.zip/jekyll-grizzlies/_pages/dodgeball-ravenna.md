---
layout: page
title: "Dodgeball a Ravenna"
description: "Vuoi giocare a Dodgeball a Ravenna? Scopri dove si gioca, chi sono i Ravenna Grizzlies e come iniziare. Allenamenti aperti a tutti, primo allenamento gratuito."
keywords: "dodgeball Ravenna, giocare dodgeball Ravenna, squadra dodgeball Ravenna, sport Ravenna, dove giocare dodgeball Ravenna"
tag: "Dodgeball a Ravenna"
og_image: "/assets/images/dodgeball-ravenna-grizzlies-hero.webp"
permalink: /dodgeball-ravenna/
---

Il Dodgeball è arrivato a Ravenna — e i **Ravenna Grizzlies** sono qui per portarti in campo.

---

## Chi porta il Dodgeball a Ravenna

I **Ravenna Grizzlies** — Dynamo Grizzly ASD — sono la squadra di riferimento per il Dodgeball a Ravenna. Fondati nel 2024, siamo già protagonisti nel campionato nazionale italiano con squadre in **Serie A Maschile**, **Serie A Femminile** e **Serie A Open**.

Tra le nostre fila ci sono **4 atleti convocati nella Nazionale Italiana** e un allenatore che ha guidato la squadra al titolo di **Campioni Europei Misto Foam**. Non male per una squadra nata meno di due anni fa.

---

## Dove si gioca a Dodgeball a Ravenna

Gli allenamenti si tengono in tre palestre della città:

**Palestra Randi** · Via G. Marconi 11, Ravenna
Adulti — Martedì e Giovedì ore 21:00

**Palestra Liceo Classico Succursale** · Via Nino Bixio 29, Ravenna
Giovanile — Lunedì ore 18:00

**Palestra Novello** · Via A. De Gasperi 4, Ravenna
Giovanile — Giovedì ore 17:30

**Palestra Mattei** · Marina di Ravenna
Femminile — Martedì ore 17:00

---

## Chi può giocare a Dodgeball a Ravenna

Chiunque. Davvero.

Non serve esperienza sportiva pregressa, non serve essere atletici o veloci. Il Dodgeball si impara velocemente e diventa subito divertente. Abbiamo atleti che hanno iniziato da zero e sono arrivati in Serie A nello stesso anno.

Abbiamo percorsi per:
- **Adulti** dai 16 anni in su — qualsiasi livello
- **Ragazzi** nelle categorie U13, U15 e U18
- **Donne** con una squadra dedicata e competitive a livello nazionale

---

## Perché scegliere i Ravenna Grizzlies

Siamo la **prima e unica squadra di Dodgeball a Ravenna** con struttura agonistica completa. Non un circolo amatoriale — una vera ASD con allenatori qualificati, atleti nazionali e risultati concreti.

Allo stesso tempo, il nostro ambiente è aperto e inclusivo. Chi viene per la prima volta trova persone disponibili, allenatori pazienti e tanta voglia di divertirsi.

---

## Come iniziare

Semplice: contattaci e vieni a un allenamento di prova. È **gratuito, senza impegno**, e capisci subito se il Dodgeball fa per te.

<div class="contact-grid" style="margin-top: 2rem;">
  <div class="contact-item">
    <span class="contact-icon">📧</span>
    <span class="contact-label">Email</span>
    <div class="contact-value">
      <a href="mailto:dynamo.grizzly@gmail.com">dynamo.grizzly@gmail.com</a>
    </div>
  </div>
  <div class="contact-item">
    <span class="contact-icon">📱</span>
    <span class="contact-label">WhatsApp / Telefono</span>
    <div class="contact-value">
      <a href="tel:+393289472121">328 947 2121</a>
    </div>
  </div>
</div>

<div style="margin-top: 2rem; display: flex; gap: 1rem; flex-wrap: wrap;">
  <a href="{{ site.baseurl }}/unisciti/" class="btn btn-primary">Unisciti ai Grizzlies ⚡</a>
  <a href="{{ site.baseurl }}/allenamenti/" class="btn btn-outline">Vedi gli orari →</a>
</div>

---

Non sai ancora cos'è il Dodgeball? [Scopri le regole e la storia →]({{ site.baseurl }}/dodgeball/)
