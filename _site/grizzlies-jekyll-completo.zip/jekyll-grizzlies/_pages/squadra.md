---
layout: default
title: "La Squadra | Ravenna Grizzlies Dodgeball"
description: "Scopri i Ravenna Grizzlies – Dynamo Grizzly ASD: storia, risultati, atleti nazionali e campioni europei. La squadra di Dodgeball di Ravenna."
keywords: "Ravenna Grizzlies squadra, Dynamo Grizzly ASD, atleti dodgeball Ravenna, risultati dodgeball Ravenna"
tag: "Chi siamo"
og_image: "/assets/images/dodgeball-ravenna-grizzlies-hero.webp"
permalink: /squadra/
---

<!-- HERO SQUADRA -->
<section class="page-hero">
  <div class="container">
    <div class="page-hero-inner" data-reveal>
      <span class="section-tag">Chi siamo</span>
      <h1>LA TANA<br><span>DELL'ORSO</span></h1>
      <div class="divider"></div>
      <p class="page-lead">Nati nel 2024, già ai vertici del Dodgeball italiano. Benvenuti nella tana dei Ravenna Grizzlies.</p>
    </div>
  </div>
</section>

<!-- ABOUT -->
<section class="section-about-full">
  <div class="container">
    <div class="about-grid" data-reveal>
      <div class="about-text">
        <p>
          I <strong>Ravenna Grizzlies</strong> — Dynamo Grizzly ASD — sono la squadra di
          <strong>Dodgeball di Ravenna</strong>, fondata nel 2024. In poco più di un anno abbiamo
          costruito una realtà sportiva che compete ai massimi livelli nazionali.
        </p>
        <p>
          Tre squadre in <strong>Serie A</strong> — Maschile, Femminile e Open — con
          <strong>4 atleti convocati in Nazionale Italiana</strong> e un allenatore che ha
          guidato la squadra al titolo di <strong>Campioni Europei Misto Foam</strong>.
        </p>
        <p>
          Il nostro ambiente è inclusivo, divertente e guidato da allenatori esperti.
          Che tu voglia competere o semplicemente allenarti, da noi sei il benvenuto.
        </p>
        <div class="about-badges" style="margin-top: 1.5rem;">
          <span class="badge">🏐 Serie A Maschile</span>
          <span class="badge">💜 Serie A Femminile</span>
          <span class="badge">⚡ Serie A Open</span>
          <span class="badge">🐻 Settore Giovanile</span>
          <span class="badge badge-gold">🏆 Campioni Europei</span>
        </div>
      </div>
      <div class="about-visual">
        <img src="{{ site.baseurl }}/assets/images/logo.png" alt="Ravenna Grizzlies Dodgeball" class="about-logo">
        <div class="about-glow"></div>
      </div>
    </div>
  </div>
</section>

<!-- STATS -->
<div class="stats-bar">
  <div class="stat" data-count="2024" data-label="Anno di fondazione"></div>
  <div class="stat" data-count="4" data-suffix="°" data-label="Campionato Nazionale"></div>
  <div class="stat" data-emoji="🥈" data-label="U16 Nazionali"></div>
  <div class="stat" data-emoji="🏆" data-label="Europei in rosa"></div>
</div>

<!-- GALLERIA -->
<section id="galleria" class="section-gallery">
  <div class="section-header container" data-reveal>
    <span class="section-tag">In campo</span>
    <h2>LA NOSTRA<br>STORIA</h2>
    <div class="divider"></div>
    <p>Momenti di gioco, sudore e vittoria.</p>
  </div>
  <div class="carousel">
    <button class="carousel-btn carousel-prev" id="carouselPrev" aria-label="Precedente">&#8249;</button>
    <div class="carousel-track" id="carouselTrack">
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-tiro-palla-rossa.webp" alt="Dodgeball Ravenna – tiro con palla rossa, Ravenna Grizzlies" loading="lazy"></div>
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-grizzlies-palla-coppia.webp" alt="Dodgeball Ravenna – due giocatori Grizzlies con la palla" loading="lazy"></div>
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-schivata-campo.webp" alt="Dodgeball Ravenna – schivata in campo durante la partita" loading="lazy"></div>
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-grizzlies-concentrazione.webp" alt="Dodgeball Ravenna – giocatore Grizzlies concentrato sul lancio" loading="lazy"></div>
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-lancio-partita.webp" alt="Dodgeball Ravenna – lancio durante partita ufficiale" loading="lazy"></div>
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-grizzlies-in-campo.webp" alt="Dodgeball Ravenna – Grizzlies in campo con palla" loading="lazy"></div>
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-tiro-avversario.webp" alt="Dodgeball Ravenna – tiro verso l'avversario" loading="lazy"></div>
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-grizzlies-attacco.webp" alt="Dodgeball Ravenna – attacco Grizzlies con due palle" loading="lazy"></div>
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-allenatore-palla.webp" alt="Dodgeball Ravenna – allenatore Grizzlies con palla" loading="lazy"></div>
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-salto-spettacolare.webp" alt="Dodgeball Ravenna – salto spettacolare durante la partita" loading="lazy"></div>
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-grizzlies-duo-palla.webp" alt="Dodgeball Ravenna – duo Grizzlies con palle rosse" loading="lazy"></div>
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-squadra-femminile.webp" alt="Dodgeball Ravenna – squadra femminile Grizzlies in azione" loading="lazy"></div>
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-raccolta-palla-linea.webp" alt="Dodgeball Ravenna – raccolta palla sulla linea di fondo" loading="lazy"></div>
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-femminile-attacco.webp" alt="Dodgeball Ravenna – attacco squadra femminile Grizzlies" loading="lazy"></div>
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-allenamento-misto.webp" alt="Dodgeball Ravenna – allenamento misto Grizzlies" loading="lazy"></div>
      <div class="carousel-slide"><img data-src="{{ site.baseurl }}/assets/images/gallery/dodgeball-ravenna-grizzlies-huddle-squadra.webp" alt="Dodgeball Ravenna – huddle di squadra Grizzlies" loading="lazy"></div>
    </div>
    <button class="carousel-btn carousel-next" id="carouselNext" aria-label="Successiva">&#8250;</button>
  </div>
  <div class="carousel-dots" id="carouselDots"></div>
</section>

<!-- CTA -->
<section class="section-contact">
  <div class="container">
    <div class="join-box" data-reveal>
      <div class="join-box-inner">
        <img src="{{ site.baseurl }}/assets/images/logo.png" alt="Grizzlies" class="join-logo">
        <div class="join-text">
          <h3>VUOI UNIRTI A NOI?</h3>
          <p>Entra nella tana — il primo allenamento è gratuito.</p>
          <div class="join-actions">
            <a href="{{ site.baseurl }}/unisciti/" class="btn btn-white">Scopri come →</a>
            <a href="tel:+393289472121" class="btn btn-outline-white">Chiamaci 📱</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
